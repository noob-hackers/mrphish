<?php
include 'ip.php';
header('Location: google.html');
?>